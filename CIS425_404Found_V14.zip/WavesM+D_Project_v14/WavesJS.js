// Team Project: 404 Found, CIS 425, 10/31/2018
// Java Script Document

function filterProducts()
{
	if (document.getElementById("ProductsSelector").value == "")
	 {
		window.open("Products.html", "_self");
	 }
	if (document.getElementById("ProductsSelector").value == "BeerNWineOption")
	 {
	 	window.open("Products_BeerNWine.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "AppsNExtrasOption")
	 {
	 	window.open("Products_AppetizersNExtras.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "BreakfastOption")
	 {
	 	window.open("Products_Breakfast.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "MexicanOption")
	 {
	 	window.open("Products_Mexican.html", "_self");
	 }
	 if (document.getElementById("ProductsSelector").value == "ColdSandwichOption")
	 {
	 	window.open("Products_coldSandwhiches.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "HotSanwichOption")
	 {
	 	window.open("Products_HotSandwiches.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "SaladOption")
	 {
	 	window.open("Products_Salad.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "KidsMealOption")
	 {
	 	window.open("Products_KidsMeals.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "DeliOption")
	 {
	 	window.open("Products_Deli.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "allOption")
	 {
	 	window.open("Products.html", "_self");	
	 }
}

// var	productName = "";
// var ProductPrice = 0;
// var productsAddedTable;
var taxRate = 0.07;
	var shippingRate = 0.01;
	var addedTax = 0;
	var addedShipping = 0;
	var totalCost = 0;

	var lbAmount = 0;

	// var totalTax = 0;
	// var totalShipping = 0;

function added2Cart(val,name)
{
	var productName = name;
	var productPrice = Number(val);

	addedTax = productPrice*taxRate;
	addedShipping = productPrice*shippingRate;
	// totalTax = totalTax+addedTax;
	// totalShipping = totalShipping + addedShipping;
	totalCost = productPrice+addedTax+addedShipping;

	alert("Item Added To Cart "+ "\n" + productName+" - $"+
		productPrice.toFixed(2)+"\n"+"Tax: $"+addedTax.toFixed(2)+
		"\n"+ "Shipping: $"+addedShipping.toFixed(2)+
		"\n"+"Total Cost: $"+totalCost.toFixed(2)); 
}

function mncadded2Cart(val,name)
{
	var productName = name;
	var productPrice = Number(val);
	var priceTimesPound = 0;
	
	// addedTax = productPrice*taxRate;
	// addedShipping = productPrice*shippingRate;
	// // totalTax = totalTax+addedTax;
	// // totalShipping = totalShipping + addedShipping;
	// totalCost = productPrice+addedTax+addedShipping;

	if (document.getElementById("mncLbs").value == "0")
	 {
		lbAmount = 0;
	 }
	if (document.getElementById("mncLbs").value == "1")
	 {
		lbAmount = 1;
	 }
	if (document.getElementById("mncLbs").value == "2")
	 {
		lbAmount = 2;
	 } 
	if (document.getElementById("mncLbs").value == "3")
	 {
		lbAmount = 3;
	 }
	if (document.getElementById("mncLbs").value == "4")
	 {
		lbAmount = 4;
	 }
	if (document.getElementById("mncLbs").value == "5")
	 {
		lbAmount = 5;
	 }
	if (document.getElementById("mncLbs").value == "6")
	 {
		lbAmount = 6;
	 }
	if (document.getElementById("mncLbs").value == "7")
	 {
		lbAmount = 7;
	 }
	if (document.getElementById("mncLbs").value == "8")
	 {
		lbAmount = 8;
	 }
	if (document.getElementById("mncLbs").value == "9")
	 {
		lbAmount = 9;
	 }
	if (document.getElementById("mncLbs").value == "10")
	 {
		lbAmount = 10;
	 } 

	 if (lbAmount == 0)
	 {
	 	alert("Please select how many pounds you would like to purchase");
	 }
	 else
	 {
	 	priceTimesPound = productPrice * lbAmount;
		addedTax = priceTimesPound*taxRate;
		addedShipping = priceTimesPound*shippingRate;
		// totalTax = totalTax+addedTax;
		// totalShipping = totalShipping + addedShipping;
		totalCost = priceTimesPound+addedTax+addedShipping;

		alert("Item Added To Cart "+ "\n" + productName + " - $" +
		productPrice.toFixed(2) +
		"\n" + "Lbs Ordered: " + lbAmount +
		"\n" + "Price x Lbs: $" + priceTimesPound.toFixed(2) +
		"\n" + "Tax: $" + addedTax.toFixed(2) +
		"\n" + "Shipping: $" + addedShipping.toFixed(2) +
		"\n" + "Total Cost: $" + totalCost.toFixed(2));
	 }

}

function saladAdd2Cart(val,name)
{
	var productName = name;
	var productPrice = Number(val);
	var priceTimesPound = 0;
	
	// addedTax = productPrice*taxRate;
	// addedShipping = productPrice*shippingRate;
	// // totalTax = totalTax+addedTax;
	// // totalShipping = totalShipping + addedShipping;
	// totalCost = productPrice+addedTax+addedShipping;

	if (document.getElementById("saladLbs").value == "0")
	 {
		lbAmount = 0;
	 }
	if (document.getElementById("saladLbs").value == "1")
	 {
		lbAmount = 1;
	 }
	if (document.getElementById("saladLbs").value == "2")
	 {
		lbAmount = 2;
	 } 
	if (document.getElementById("saladLbs").value == "3")
	 {
		lbAmount = 3;
	 }
	if (document.getElementById("saladLbs").value == "4")
	 {
		lbAmount = 4;
	 }
	if (document.getElementById("saladLbs").value == "5")
	 {
		lbAmount = 5;
	 }
	if (document.getElementById("saladLbs").value == "6")
	 {
		lbAmount = 6;
	 }
	if (document.getElementById("saladLbs").value == "7")
	 {
		lbAmount = 7;
	 }
	if (document.getElementById("saladLbs").value == "8")
	 {
		lbAmount = 8;
	 }
	if (document.getElementById("saladLbs").value == "9")
	 {
		lbAmount = 9;
	 }
	if (document.getElementById("saladLbs").value == "10")
	 {
		lbAmount = 10;
	 } 

	 if (lbAmount == 0)
	 {
	 	alert("Please select how many pounds you would like to purchase");
	 }
	 else
	 {
	 	priceTimesPound = productPrice * lbAmount;
		addedTax = priceTimesPound*taxRate;
		addedShipping = priceTimesPound*shippingRate;
		// totalTax = totalTax+addedTax;
		// totalShipping = totalShipping + addedShipping;
		totalCost = priceTimesPound+addedTax+addedShipping;

		alert("Item Added To Cart "+ "\n" + productName + " - $" +
		productPrice.toFixed(2) +
		"\n" + "Lbs Ordered: " + lbAmount +
		"\n" + "Price x Lbs: $" + priceTimesPound.toFixed(2) +
		"\n" + "Tax: $" + addedTax.toFixed(2) +
		"\n" + "Shipping: $" + addedShipping.toFixed(2) +
		"\n" + "Total Cost: $" + totalCost.toFixed(2));
	 }
}

function viewCart()
{
	window.open("Cart.html", "_self");
}