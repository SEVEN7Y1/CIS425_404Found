// Team Project: 404 Found, CIS 425, 10/31/2018
// Java Script Document

function filterProducts()
{
	if (getElementById("ProductsSelector").value == "BeerNWineOption")
	 {
	 	window.open(Products_BeerNWine.html);	
	 }
}
//this isnt working by my brain is tired so i quuit