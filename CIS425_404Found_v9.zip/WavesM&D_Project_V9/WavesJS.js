// Team Project: 404 Found, CIS 425, 10/31/2018
// Java Script Document

function filterProducts()
{
	if (document.getElementById("ProductsSelector").value == "")
	 {
		window.open("Products.html", "_self");
	 }
	if (document.getElementById("ProductsSelector").value == "BeerNWineOption")
	 {
	 	window.open("Products_BeerNWine.html", "_self");	
	 }
}
function allProducts()
{
	window.open("Products.html", "_self");
}
//this is working needs to be duplicated for all product pages