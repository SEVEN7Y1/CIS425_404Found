// Team Project: 404 Found, CIS 425, 10/31/2018
// Java Script Document