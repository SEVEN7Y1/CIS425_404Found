// Team Project: 404 Found, CIS 425, 10/31/2018
// Java Script Document

function filterProducts()
{
	if (document.getElementById("ProductsSelector").value == "")
	 {
		window.open("Products.html", "_self");
	 }
	if (document.getElementById("ProductsSelector").value == "BeerNWineOption")
	 {
	 	window.open("Products_BeerNWine.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "AppsNExtrasOption")
	 {
	 	window.open("Products_AppetizersNExtras.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "BreakfastOption")
	 {
	 	window.open("Products_Breakfast.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "ColdSandwichOption")
	 {
	 	window.open("Products_coldSandwhiches.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "HotSanwichOption")
	 {
	 	window.open("Products_HotSandwiches.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "SaladOption")
	 {
	 	window.open("Products_Salad.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "KidsMealOption")
	 {
	 	window.open("Products_KidsMeals.html", "_self");	
	 }
	 if (document.getElementById("ProductsSelector").value == "DeliOption")
	 {
	 	window.open("Products_Deli.html", "_self");	
	 }
}

// var	productName = "";
// var ProductPrice = 0;
// var productsAddedTable;
var taxRate = 0.07;
	var addedTax = 0;
	var shippingRate = 0.01;
	var addedShipping = 0;
	var totalTax = 0;
	var totalShipping = 0;
	var totalCost = 0;

function added2Cart(val,name)
{
	var productName = name;
	var productPrice = val;

	addedTax = productPrice*taxRate;
	addedShipping = productPrice*shippingRate;
	totalTax = totalTax+addedTax;
	totalShipping = totalShipping + addedShipping;
	totalCost = totalCost + totalShipping + totalTax + productPrice;

	alert("Item Added To Cart "+productName+" - "+productPrice+
			"Tax: "+totalTax+"shipping: "+totalShipping+
			"total Cost: "+totalCost); 

	// productName = document.getElementById('productsAddedToTableID');
	// productName = name;
	// ProductPrice = val;
	// var tableRowNum = 1;

	// var row = productsAddedTable.insertRow(tableRowNum);
	// var cell0 = row.insertCell(0);
	// cell0.innerHTML = name;

	// tableRowNum++;

}
